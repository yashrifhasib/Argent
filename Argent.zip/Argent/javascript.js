function initialize() {
    money=0;
    balanceOutput=document.getElementById("mymoney");
    detailsInput=document.getElementById("details");
    amountInput=document.getElementById("amount");
    dateInput=document.getElementById("date");
}
function money(){
    money=balance;
}
function display(){
    balanceOutput.innerHTML=money;
}